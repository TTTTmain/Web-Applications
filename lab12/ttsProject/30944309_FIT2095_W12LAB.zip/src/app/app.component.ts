import { Component, OnInit } from '@angular/core';
import * as io from 'socket.io-client';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'ttsProject';
  inputText:String = "";
  socket: SocketIOClient.Socket;
  selectedLang:String = "";
  audioPath:String = "";
  showPlayer:boolean = false;
  translatedText:String = "";
  translatedLangLbl:String = "";
  langToTranslate = [
    {lang:'Thai',val:'th-TH'},
    {lang:'Japanese',val:'ja-JP'},
    {lang:'Vietnamese',val:'vi_VN'},
    {lang:'German',val:'de-DE'}
  ]

  ngOnInit(){
    this.waitForAudio();
  }

  constructor(){
    this.socket = io.connect();
  }

  waitForAudio(){
    this.showPlayer = false;
    this.socket.on('new-audio',(data)=>{
      console.log(data);
      this.audioPath = data.audioPath;
      this.translatedText = data.translatedText
      this.showPlayer = true;
    });
  }

  refreshPage(){
    location.reload()
  }

  getFullLang(tranCode){
    for(let i=0;i<this.langToTranslate.length;i++){
      if(this.langToTranslate[i].val === tranCode){
        return this.langToTranslate[i].lang;
      }
    }
  }

  submitText(){
    let userData = {userInput:this.inputText, langToTran:this.selectedLang,translateCode: this.selectedLang.substr(0,2)}
    this.translatedLangLbl = this.getFullLang(this.selectedLang);
    console.log(JSON.stringify(userData));
    this.socket.emit('send-text',userData);
    
  }
}
